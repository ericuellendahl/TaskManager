﻿namespace TaskManager.Application.DTOs;

public class CreateProjectDto
{
    public string Name { get; set; }
    public string Description { get; set; }
}
