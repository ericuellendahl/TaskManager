﻿namespace TaskManager.Domain.Entities;

public enum TaskUserPriority
{
    Low = 0,
    Medium = 1,
    High = 2
}
