namespace TaskManager.Domain.Entities;

public enum TaskUserStatus
{
    Pending = 0,
    InProgress = 1,
    Completed = 2
}