﻿namespace TaskManager.Domain.Entities;

public enum UserRole
{
    User = 0,
    Manager = 1
}
