namespace TaskManager.Domain.Enums
{
    public enum TaskStatus { Pendente, EmAndamento, Concluida }
}