namespace TaskManager.Domain.Enums
{
    public enum TaskPriority { Baixa, Media, Alta }
}