## Como Executar

### Via Docker Compose (Recomendado)

1. Clone o repositório
2. Navegue até a pasta raiz do projeto
3. Execute o comando:

```bash
docker-compose up -d
```

4. A API estará disponível em `http://localhost:8080`
5. O Swagger estará em `http://localhost:8080/swagger`

### Via .NET CLI

1. Certifique-se de ter o .NET 8 SDK instalado
2. Configure uma instância do SQL Server
3. Atualize a connection string no `appsettings.json`
4. Execute:

```bash
dotnet restore
dotnet build
dotnet run --project src/TaskManagement.API
```

## Endpoints da API

### Projetos
- `GET /api/projects` - Lista todos os projetos do usuário
- `POST /api/projects` - Cria um novo projeto
- `GET /api/projects/{id}/tasks` - Lista tarefas de um projeto
- `DELETE /api/projects/{id}` - Remove um projeto

### Tarefas
- `POST /api/tasks` - Cria uma nova tarefa
- `PUT /api/tasks/{id}` - Atualiza uma tarefa
- `DELETE /api/tasks/{id}` - Remove uma tarefa
- `POST /api/tasks/{id}/comments` - Adiciona comentário a uma tarefa

### Relatórios
- `GET /api/reports/performance` - Relatório de performance (apenas gerentes)

## Testes

Execute os testes unitários com:

```bash
dotnet test
```

O projeto mantém mais de 80% de cobertura de código conforme especificado.

## Tecnologias Utilizadas

- .NET 8
- Entity Framework Core
- Bando InMemory
- Docker
- xUnit (testes)
- Swagger/OpenAPI

---


